## Command

Please run the command "make" followed by "./shell"
